
package figura;

/**
 * Programa con las operaciones pertinentes para poder obetener la solución que queremos.
 * @author "Noelia Díaz Ayllón*
 * @author noelia.diaz@campusfp.es
 * @version 1.1
 * @see <a href='http://www.datanoelia.com'> noelia.com - Aprender a programar </a>  Este enlace es un enlace ficticio.
 * 
 */

public class circulo {
    
    /*
    *Creamos tres tipos private
    */
    
    private double centrox;
    private double centroy;
    private double radio;
    
    public circulo(){
    }
    
    /*
    *Definimos las variables creadas anteriormente
    */
    
    public circulo(double centrox, double centroy, double radio){
        this.centrox = centrox;
        this.centroy = centroy;
        this.radio = radio;
    }
    
    //Hacemos que devuelva la variable centrox
    
    public double getCentrox(){
        return centrox;
    }
    
    //Definimos la variable centrox
    
    public void setCentrox(double centrox){
        this.centrox = centrox;
    }
        
    //Hacemos que devuelva la variable centroy
    
    public double getCentroy(){
        return centroy;
    }
    
    //Definimos la variable centroy
       
    public void setCentroy(double centroy){
        this.centroy = centroy;
    }
    
    //Hacemos que devuelva la variable radio
    
    public double getRadio(){
        return radio;
    }
    
    //Definimos la variable radio

    public void setRadio(double radio){
        this.radio = radio;
    }
    
    @Override
    
    //Creamos una string para mostrar por pantalla el texto que introduce las variables seguido de las propias variables.
    
    public String toString(){
        return "Circulo(" + "centrox=" + centrox + ", centroy=" + centroy + ", radio=" + radio + ')';
    }
    
    //Ponemos los cálculos necesarios para poder calcular el perímetro del circulo.
    
    public double perimetroCirculo(){
        return 2 * Math.PI * this.radio;
    }
    
    //Ponemos los cálculos necesarios para poder calcular el área del circulo.
    
    public double areCirculo(){
        return Math.PI * Math.pow(this.radio,2);
    }
    
    //Defiminimos las variables con sus operaciones pertinentes para poder crear la public void moverCirculo
    
    public void moverCirculo(double deltax, double deltay){
        this.centrox = this.centrox + deltax;
        this.centroy = this.centroy + deltay;
    }

    //Ponemos los cálculos necesarios para poder calcular la escala del circulo.
    
    public void escalaCirculo(double s){
        this.radio = this.radio * s;
    }
    
}
