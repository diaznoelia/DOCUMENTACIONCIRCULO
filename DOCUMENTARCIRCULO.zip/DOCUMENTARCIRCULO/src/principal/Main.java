
package principal;

import figura.circulo;

/**
 * Programa principal que muestra por pantalla el cálculo hecho con los datos introducidos en base a la clase círculo y a la clase Main.
 * @author "Noelia Díaz Ayllón*
 * @author noelia.diaz@campusfp.es
 * @version 1.1
 * @see <a href='http://www.datanoelia.com'> noelia.com - Aprender a programar </a> Este enlace es un enlace ficticio.
 * 
 */
public class Main {

    /**
     * 
     * Creamos una public static void y en ella introducimos valores.
     * 
     * Después de introducir valores los printamos todos por pantalla a través de un System.out.println.
     * 
     * En este System.out.println ponemos texto para introducir el resultado y seguido de este, ponemos la variable que queramos
     * para así poder imprimir el resultado por pantalla.
     * 
     * @param args es un arreglo de tipo string.
     */
    
    public static void main(String[] args) {
        double centrox = 1;
        double centroy = 1;
        double radio = 5;
        circulo c1 = new circulo(centrox,centroy,radio);
        System.out.println("Área del círculo = " + c1.areCirculo());
        System.out.println("Perímetro del círculo = " + c1.perimetroCirculo());
        c1.moverCirculo(10, 10);
        System.out.println("Centro x nuevo = " + c1.getCentrox());
        System.out.println("Centro y nuevo = " + c1.getCentroy());
    }
    
}
